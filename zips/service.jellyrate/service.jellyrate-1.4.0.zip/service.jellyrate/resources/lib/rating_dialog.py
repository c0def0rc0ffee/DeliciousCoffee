# -*- coding: utf-8 -*-
"""The 1-10 star rating dialog shown after playback (Trakt-style).

Ten stars in a row: move left/right to choose, press OK on a star to confirm,
press down for Cancel, Back to dismiss. Navigation is driven explicitly in
onAction so it works reliably with a remote (the old slider control only
responded to the mouse)."""
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))

SKIN_XML = "script-jellyrate-rating.xml"

MIN_RATING = 1
MAX_RATING = 10

# Control ids (must match the skin xml).
TITLE_LABEL_ID = 10
PREVIOUS_LABEL_ID = 11
VALUE_LABEL_ID = 12
STAR_BUTTON_BASE = 100      # star buttons are 101..110  (value = id - 100)
STAR_FILLED_BASE = 300      # filled-star images are 301..310
CANCEL_ID = 200

_CANCEL_ACTIONS = (
    xbmcgui.ACTION_PREVIOUS_MENU,
    xbmcgui.ACTION_NAV_BACK,
)


class _RatingDialog(xbmcgui.WindowXMLDialog):
    # Defaults; the caller overrides these before doModal().
    title = ""
    value = 5
    previous = None
    confirmed = False

    # ------------------------------------------------------------------ #
    def onInit(self):
        self.value = max(MIN_RATING, min(MAX_RATING, int(self.value)))
        try:
            self.getControl(TITLE_LABEL_ID).setLabel(self.title)
        except Exception:
            pass
        try:
            if self.previous is not None:
                hint = "Previously rated: %d / %d" % (
                    int(round(self.previous)),
                    MAX_RATING,
                )
            else:
                hint = "Not yet rated"
            self.getControl(PREVIOUS_LABEL_ID).setLabel(hint)
        except Exception:
            pass
        self._paint()
        try:
            self.setFocusId(STAR_BUTTON_BASE + self.value)
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    def _paint(self):
        """Fill stars up to the current value; update the numeric label."""
        for star in range(MIN_RATING, MAX_RATING + 1):
            try:
                self.getControl(STAR_FILLED_BASE + star).setVisible(
                    star <= self.value
                )
            except Exception:
                pass
        try:
            self.getControl(VALUE_LABEL_ID).setLabel(
                "%d / %d" % (self.value, MAX_RATING)
            )
        except Exception:
            pass

    def _set_value(self, value):
        value = max(MIN_RATING, min(MAX_RATING, value))
        if value != self.value:
            self.value = value
            self._paint()
        try:
            self.setFocusId(STAR_BUTTON_BASE + self.value)
        except Exception:
            pass

    def _focused_star(self):
        focus = self.getFocusId()
        if STAR_BUTTON_BASE + MIN_RATING <= focus <= STAR_BUTTON_BASE + MAX_RATING:
            return focus - STAR_BUTTON_BASE
        return None

    # ------------------------------------------------------------------ #
    def onAction(self, action):
        action_id = action.getId()
        if action_id in _CANCEL_ACTIONS:
            self.confirmed = False
            self.close()
            return

        on_star = self._focused_star() is not None
        if action_id == xbmcgui.ACTION_MOVE_LEFT and on_star:
            self._set_value(self.value - 1)
        elif action_id == xbmcgui.ACTION_MOVE_RIGHT and on_star:
            self._set_value(self.value + 1)
        elif action_id == xbmcgui.ACTION_MOVE_DOWN and on_star:
            try:
                self.setFocusId(CANCEL_ID)
            except Exception:
                pass
        elif action_id == xbmcgui.ACTION_MOVE_UP and not on_star:
            self._set_value(self.value)  # return focus to the chosen star

    def onClick(self, control_id):
        star = control_id - STAR_BUTTON_BASE
        if MIN_RATING <= star <= MAX_RATING:
            self.value = star
            self.confirmed = True
            self.close()
        elif control_id == CANCEL_ID:
            self.confirmed = False
            self.close()


def _ask_with_stars(title, default_value, previous):
    dialog = _RatingDialog(SKIN_XML, ADDON_PATH, "Default", "1080i")
    dialog.title = title
    dialog.value = max(MIN_RATING, min(MAX_RATING, int(default_value)))
    dialog.previous = previous
    dialog.doModal()
    confirmed = dialog.confirmed
    value = dialog.value
    del dialog
    return value if confirmed else None


def _ask_with_select(title, default_value, previous):
    """Plain fallback if the custom window cannot be loaded for any reason."""
    options = ["%d" % i for i in range(MIN_RATING, MAX_RATING + 1)]
    if previous is not None:
        prev_int = int(round(previous))
        for idx, opt in enumerate(options):
            if int(opt) == prev_int:
                options[idx] = "%s  (previous)" % opt
    preselect = max(0, min(len(options) - 1, int(default_value) - MIN_RATING))
    choice = xbmcgui.Dialog().select(
        "Rate: %s" % title if title else "Rate", options, preselect=preselect
    )
    if choice < 0:
        return None
    return choice + MIN_RATING


def ask_rating(title="", default_value=5, previous=None):
    """Prompt for a 1-10 rating. Returns an int, or None if cancelled.

    ``previous`` is the existing Jellyfin rating (float) or None; it is shown
    as a hint and the stars start on it.
    """
    try:
        return _ask_with_stars(title, default_value, previous)
    except Exception as exc:
        xbmc.log(
            "[service.jellyrate] star dialog failed (%s); using select list"
            % exc,
            xbmc.LOGWARNING,
        )
        return _ask_with_select(title, default_value, previous)
