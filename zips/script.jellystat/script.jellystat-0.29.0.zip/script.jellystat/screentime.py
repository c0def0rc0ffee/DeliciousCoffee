# -*- coding: utf-8 -*-
"""
<summary>
Headline tiles and the screen-time panel.
</summary>
<remarks>
Two different questions, answered from two different places, and the split
matters because getting it wrong would invent numbers:

- **Tiles** ("this month" and "all time") count titles and estimate hours
  from each item's runtime times how often it was played. That reaches back
  over the whole library, including everything watched before this addon
  existed, but it is an estimate: it assumes a play means the whole thing.

- **Screen time** comes from the play log's real sittings, so it only covers
  the period the log reaches back to. Every figure carries the window it was
  measured over and a comparison against the window before it, because "6h
  3m a day" only means something next to what it used to be.

  Not all of it is measured, though, and the panel says which is which. A
  sitting recorded by this box has a real duration; one imported from Trakt
  or a similar service has only the item's runtime, because those services
  record *that* something was played and never for how long. Both are
  reported, separately, rather than adding an assumption to a measurement
  and presenting the sum as fact.
</remarks>
"""

from datetime import datetime, timedelta

import xbmc

import library
import playlog
import timeparse

# Where the day is cut into named parts, matching how people describe
# viewing rather than any clock convention.
DAYPARTS = (("Morning", 5, 12), ("Afternoon", 12, 17),
            ("Evening", 17, 22), ("Night", 22, 5))

# A day is not 24 usable hours. The share of *waking* time is the number
# worth showing, and this is the assumption behind it.
WAKING_HOURS = 16.0


def log(message, level=xbmc.LOGINFO):
    """
    <summary>
    Write one line to Kodi's log under the JellyStat tag.
    </summary>
    <param name="message">Text to log.</param>
    <param name="level">Kodi log level, info by default.</param>
    """
    xbmc.log("[JellyStat] %s" % message, level)


def _connect():
    """
    <summary>
    A connection with both schemas already in place.
    </summary>
    <remarks>
    Everything here reads the play log as well as the mirror. The two live
    in one file but are created by different modules, and library.connect()
    builds only the mirror's half: it leaves the plays table to whichever
    module touches playlog first. On a fresh install that was a race this
    could lose: the dashboard opens /api/data and /api/screentime together,
    /api/data spends seconds fetching from Jellyfin before it reaches the
    play log, and screen time got there first and asked for a table nobody
    had made yet. Asking playlog for the schema costs nothing after the
    first call and settles it.
    </remarks>
    """
    playlog.connect().close()
    return library.connect()


# ---------------------------------------------------------------------------
# Tiles
# ---------------------------------------------------------------------------

def _tile_row(connection):
    """
    <summary>
    Counts and estimated minutes for everything the mirror holds.
    </summary>
    """
    # Series rows exist to hold show-level ratings; they are not watched
    # items and must not be counted as titles or minutes here.
    row = connection.execute(
        "SELECT "
        "SUM(CASE WHEN media='episode' THEN 1 ELSE 0 END), "
        "COUNT(DISTINCT CASE WHEN media='episode' THEN series_name END), "
        "SUM(CASE WHEN media='movie' THEN 1 ELSE 0 END), "
        "SUM(play_count), "
        # Runtime times plays: what the item is worth, however often watched.
        "SUM(COALESCE(runtime_minutes, 0) * MAX(play_count, 1)), "
        "SUM(CASE WHEN user_rating IS NOT NULL THEN 1 ELSE 0 END) "
        "FROM items WHERE media IN ('movie', 'episode')").fetchone()
    return {
        "episodes": row[0] or 0,
        "shows": row[1] or 0,
        "movies": row[2] or 0,
        "plays": row[3] or 0,
        "minutes": row[4] or 0,
        "ratings": row[5] or 0,
    }


def _tile_row_since(connection, since, dates):
    """
    <summary>
    The same counts for the titles last watched on or after a local stamp.
    </summary>
    <param name="connection">An open mirror connection.</param>
    <param name="since">A local YYYY-MM-DDTHH:MM:SS stamp.</param>
    <param name="dates">A library.LastWatched built on this connection.</param>
    <remarks>
    Walked in Python rather than filtered in SQL because "last watched"
    is the dashboard's rule (the play log first, Jellyfin's date only as
    the fallback), not a column. Until this, the month tile compared the
    mirror's UTC copy of Jellyfin's date, so a bulk re-mark on the server
    put the whole library into one month on every skin that showed these
    properties, while every page of the dashboard had moved on. The
    whole mirror is read once per call, which the service does once every
    few minutes; a library of ten thousand rows is a fraction of a second.
    </remarks>
    """
    rows = connection.execute(
        "SELECT media, series_name, name, year, play_count, "
        "runtime_minutes, user_rating, last_played FROM items "
        "WHERE media IN ('movie', 'episode')")
    out = {"episodes": 0, "shows": set(), "movies": 0, "plays": 0,
           "minutes": 0, "ratings": 0}
    for media, series, name, year, plays, runtime, score, played in rows:
        when = dates.title(played, series if media == "episode" else None,
                           name, year)
        if not when or when < since:
            continue
        if media == "episode":
            out["episodes"] += 1
            out["shows"].add(series)
        else:
            out["movies"] += 1
        out["plays"] += plays or 0
        out["minutes"] += (runtime or 0) * max(plays or 0, 1)
        if score is not None:
            out["ratings"] += 1
    out["shows"] = len(out["shows"])
    return out


def tiles(now=None):
    """
    <summary>
    The two headline blocks: this month, and all time.
    </summary>
    <remarks>
    The month boundary is local midnight on the first, compared against
    local last watched stamps: the rule in library.LastWatched hands back
    local time whichever side (the log or Jellyfin's date) answered, so no
    UTC arithmetic is needed here any more.
    </remarks>
    """
    now = now or datetime.now()
    month_start = now.replace(day=1, hour=0, minute=0, second=0,
                              microsecond=0).strftime("%Y-%m-%dT%H:%M:%S")
    connection = _connect()
    try:
        dates = library.LastWatched(connection)
        this_month = _tile_row_since(connection, month_start, dates)
        all_time = _tile_row(connection)
    finally:
        connection.close()
    return {
        "month_label": now.strftime("%B"),
        "this_month": this_month,
        "all_time": all_time,
    }


# ---------------------------------------------------------------------------
# Screen time
# ---------------------------------------------------------------------------

def _daypart(hour):
    """
    <summary>
    The named part of the day an hour falls in, handling the one that wraps midnight.
    </summary>
    <param name="hour">0 to 23.</param>
    <returns>A DAYPARTS name, Night when nothing matches.</returns>
    """
    for name, start, end in DAYPARTS:
        if start < end:
            if start <= hour < end:
                return name
        elif hour >= start or hour < end:      # the wrap-around one
            return name
    return "Night"


def _window(connection, start_day, end_day):
    """
    <summary>
    Measured minutes in a date range, split the ways the panel shows.
    </summary>
    """
    rows = connection.execute(
        "SELECT day, hour, media, watched_seconds, "
        "COALESCE(assumed, 0) FROM plays "
        "WHERE day >= ? AND day <= ?", (start_day, end_day)).fetchall()
    per_day = {}
    per_day_assumed = {}
    dayparts = {name: 0 for name, _, _ in DAYPARTS}
    movies = shows = measured = assumed = 0
    for day, hour, media, seconds, is_assumed in rows:
        minutes = (seconds or 0) / 60.0
        per_day[day] = per_day.get(day, 0.0) + minutes
        if is_assumed:
            assumed += minutes
            per_day_assumed[day] = per_day_assumed.get(day, 0.0) + minutes
        else:
            measured += minutes
        if hour is not None and hour >= 0:
            dayparts[_daypart(hour)] += 1
        if media == "movie":
            movies += minutes
        elif media == "episode":
            shows += minutes
    total = sum(per_day.values())
    return {"per_day": per_day, "per_day_assumed": per_day_assumed,
            "dayparts": dayparts, "movies": movies, "shows": shows,
            "total": total, "measured": measured, "assumed": assumed,
            "sessions": len(rows)}


def _days(start, count):
    """
    <summary>
    Consecutive dates from a start, as YYYY-MM-DD strings.
    </summary>
    <param name="start">A date.</param>
    <param name="count">How many.</param>
    <returns>A list of strings.</returns>
    """
    return [(start + timedelta(days=i)).strftime("%Y-%m-%d")
            for i in range(count)]


def screen_time(days=7, now=None):
    """
    <summary>
    The panel: daily bars, average, dayparts, totals, all with deltas.
    </summary>
    <remarks>
    Compared against the immediately preceding window of the same length,
    which is what makes a number like "-31m" meaningful.
    </remarks>
    """
    now = now or datetime.now()
    today = now.date()
    start = today - timedelta(days=days - 1)
    previous_start = start - timedelta(days=days)
    previous_end = start - timedelta(days=1)

    connection = _connect()
    try:
        current = _window(connection, start.strftime("%Y-%m-%d"),
                          today.strftime("%Y-%m-%d"))
        earlier = _window(connection, previous_start.strftime("%Y-%m-%d"),
                          previous_end.strftime("%Y-%m-%d"))
        covered = playlog.since()
    finally:
        connection.close()

    labels = _days(start, days)
    breakdown = [{"date": day,
                  "weekday": timeparse.strptime(day, "%Y-%m-%d").weekday(),
                  "minutes": round(current["per_day"].get(day, 0.0)),
                  "assumed_minutes": round(
                      current["per_day_assumed"].get(day, 0.0)),
                  "today": day == today.strftime("%Y-%m-%d")}
                 for day in labels]

    # Divides by the days the log actually covers, not by the whole window:
    # a log that began three days ago should not report a seventh of its
    # rate. (The old sum here worked out to `days` every time, because
    # `start` is defined as exactly that many days back, so the intent
    # this comment describes was never actually applied.)
    elapsed = days
    if covered:
        try:
            first = timeparse.strptime(covered, "%Y-%m-%d").date()
        except ValueError:
            first = None
        if first and first > start:
            elapsed = max(1, (today - first).days + 1)
    average = current["total"] / elapsed if elapsed else 0.0
    previous_average = earlier["total"] / days if days else 0.0

    return {
        "days": days,
        "from": start.strftime("%Y-%m-%d"),
        "to": today.strftime("%Y-%m-%d"),
        "covered_from": covered,
        "measured": bool(current["sessions"] or earlier["sessions"]),
        "breakdown": breakdown,
        "daily_average": {"minutes": round(average),
                          "delta": round(average - previous_average)},
        "total": {"minutes": round(current["total"]),
                  "delta": round(current["total"] - earlier["total"])},
        # Reported alongside every figure above, never folded into them.
        "measured_minutes": round(current["measured"]),
        "assumed_minutes": round(current["assumed"]),
        "waking": {"percent": round(100.0 * (average / 60.0) / WAKING_HOURS,
                                    1),
                   "delta": round(100.0 * ((average - previous_average) / 60.0)
                                  / WAKING_HOURS, 1)},
        "movies": {"minutes": round(current["movies"]),
                   "delta": round(current["movies"] - earlier["movies"])},
        "shows": {"minutes": round(current["shows"]),
                  "delta": round(current["shows"] - earlier["shows"])},
        "dayparts": [{"name": name, "sessions": current["dayparts"][name]}
                     for name, _, _ in DAYPARTS],
    }
