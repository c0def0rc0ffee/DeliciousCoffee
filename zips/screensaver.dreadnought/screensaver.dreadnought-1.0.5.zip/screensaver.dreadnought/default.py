"""Dreadnought screensaver for Kodi.

Loops a short clip of the Dreadnought in a fullscreen window until the user
presses a key. Needs Kodi 19 (Matrix) or later.

Kodi has a few traps for video screensavers, so this is how it hangs together:

1. The clip is played with windowed=True into a fullscreen videowindow
   control in our own WindowXMLDialog. That way there is no OSD, no seek bar
   and no switch to Kodi's fullscreen video window.
2. Starting playback wakes Kodi's screensaver state (PlayListPlayer calls
   WakeUpScreenSaverAndDPMS). Kodi then announces OnScreensaverDeactivated
   and arms an alarm called "sssssscreensaver" that runs StopScript() on
   this script 15 seconds later (ApplicationPowerHandling.cpp). So the
   deactivation that arrives right after play() is ignored, and the alarm is
   cancelled on every tick of the watch loop. From then on the dialog is an
   ordinary modal window and closes itself on the first key press.
3. The clip goes through the video playlist, queued twice with repeat set
   to "all", which loops without a black gap between passes. Twice, not
   once: Kodi's PlayFile() consumes the "start windowed" flag on the first
   item and, for a one item playlist, opens every later pass fullscreen
   (Application.cpp, the playlist size() > 1 branch is the only one that
   stays windowed once the first file has played). The previous repeat mode
   and mute state are put back on exit.
4. If something is already playing (paused video, music) the screensaver
   leaves the player alone: it shows a black screen and closes on
   deactivation like any other screensaver.
5. While the clip plays the Home window carries the property
   VideoScreensaverRunning=true, the flag the old screensaver.video add-on
   used and that script.skin.helper.service and script.pinsentry check, so
   services that react to playback can tell this is a screensaver and not a
   film. Kodi itself has no way to mark a playback as "not real".
6. Muting is done before the window opens and undone after it closes.
   Kodi implements Application.SetMute by sending ACTION_MUTE to the
   topmost window, so muting from inside the dialog closes the screensaver
   on the spot (observed: "closing: user input (action 91)"). The volume
   bar that the mute opens is closed by hand, because Kodi keeps it open
   for as long as the sound is muted.
"""

import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
VIDEO_PATH = os.path.join(ADDON_PATH, 'resources', 'media', 'Dreadnought.mp4')
WINDOW_XML = 'screensaver-dreadnought.xml'

# Must match SCRIPT_ALARM in Kodi's ApplicationPowerHandling.cpp.
SCRIPT_ALARM = 'sssssscreensaver'
# The deactivation Kodi announces after play() is our own wake. It normally
# arrives within a second; anything later than this is treated as real.
WAKE_GRACE_SECONDS = 60.0
# How long to wait for the first frame before giving up on setting repeat.
PLAYER_START_TIMEOUT = 8.0
# Ticks of the watch loop with no playback before the clip is restarted.
RESTART_AFTER_TICKS = 3
# Actions that should not end the screensaver: ACTION_NONE and
# ACTION_TAKE_SCREENSHOT (a screenshot of the clip is a fair thing to want).
IGNORED_ACTIONS = (0, 85)
# Home window property other add-ons can check to ignore our playback.
HOME_WINDOW_ID = 10000
RUNNING_PROPERTY = 'VideoScreensaverRunning'


def set_running_flag(running):
    home = xbmcgui.Window(HOME_WINDOW_ID)
    if running:
        home.setProperty(RUNNING_PROPERTY, 'true')
    else:
        home.clearProperty(RUNNING_PROPERTY)


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[{}] {}'.format(ADDON_ID, message), level)


def jsonrpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}}
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except ValueError as exc:
        log('JSON-RPC {} returned bad JSON: {}'.format(method, exc), xbmc.LOGWARNING)
        return None
    if 'error' in response:
        log('JSON-RPC {} failed: {}'.format(method, response['error']), xbmc.LOGWARNING)
        return None
    return response.get('result')


def cancel_stop_script_alarm():
    xbmc.executebuiltin('CancelAlarm({},true)'.format(SCRIPT_ALARM))


def close_busy_dialogs():
    xbmc.executebuiltin('Dialog.Close(busydialog,true)')
    xbmc.executebuiltin('Dialog.Close(busydialognocancel,true)')


def close_volume_bar():
    # Kodi opens the volume bar on every mute or volume change and, while
    # muted, cancels its auto close, so the "Muted" bar would sit over the
    # clip for the whole run (GUIDialogVolumeBar.cpp).
    xbmc.executebuiltin('Dialog.Close(volumebar,true)')


def video_player_id():
    for player in jsonrpc('Player.GetActivePlayers') or []:
        if player.get('type') == 'video':
            return player.get('playerid')
    return None


class LoopPlayer(xbmc.Player):
    """Reports playback events back to the screensaver window."""

    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self)
        self.owner = kwargs['owner']

    def onAVStarted(self):
        close_busy_dialogs()
        cancel_stop_script_alarm()
        self.owner.on_av_started()

    def onPlayBackError(self):
        self.owner.on_playback_error()


class ExitMonitor(xbmc.Monitor):
    """Closes the window when Kodi says the screensaver is over."""

    def __init__(self, *args, **kwargs):
        xbmc.Monitor.__init__(self)
        self.owner = kwargs['owner']

    def onScreensaverDeactivated(self):
        self.owner.on_screensaver_deactivated()

    def onDPMSActivated(self):
        self.owner.exit('display power saving started')


class Screensaver(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.lock = threading.Lock()
        self.closed = False
        self.play_started_at = None
        self.expect_wake = False
        self.av_started = False
        self.playback_error = False
        self.saved_repeat = None
        self.player = None
        self.monitor = None
        self.worker = None

    # Kodi callbacks

    def onInit(self):
        self.player = LoopPlayer(owner=self)
        self.monitor = ExitMonitor(owner=self)
        self.worker = threading.Thread(target=self.run, name='dreadnought-screensaver')
        self.worker.daemon = True
        self.worker.start()

    def onAction(self, action):
        action_id = action.getId()
        if action_id in IGNORED_ACTIONS:
            return
        self.exit('user input (action {})'.format(action_id))

    def on_av_started(self):
        self.av_started = True

    def on_playback_error(self):
        self.playback_error = True

    def on_screensaver_deactivated(self):
        started = self.play_started_at
        recent = started is not None and time.monotonic() - started < WAKE_GRACE_SECONDS
        if self.expect_wake and recent:
            self.expect_wake = False
            log('ignoring the screensaver wake caused by starting playback')
            return
        self.exit('screensaver deactivated')

    # Worker thread

    def run(self):
        try:
            if self.closed:
                return
            if self.player.isPlaying():
                log('media is already playing, showing a blank screen instead of the clip')
            elif not os.path.isfile(VIDEO_PATH):
                log('clip not found: {}'.format(VIDEO_PATH), xbmc.LOGERROR)
            else:
                self.start_clip()
            self.watch()
        except Exception as exc:
            log('worker failed: {!r}'.format(exc), xbmc.LOGERROR)
        self.exit('worker finished')

    def watch(self):
        idle_ticks = 0
        ticks = 0
        while not self.closed and not self.monitor.waitForAbort(1.0):
            if self.play_started_at is None:
                continue
            ticks += 1
            cancel_stop_script_alarm()
            if ticks <= 3:
                close_volume_bar()
            if xbmc.getCondVisibility('Window.IsActive(fullscreenvideo)'):
                # Should never happen with the two item playlist. If it does,
                # leave cleanly rather than sit behind Kodi's video window.
                self.exit('Kodi switched to the fullscreen video window')
                return
            if ticks % 30 == 0:
                log('running for {} s, playing={}'.format(ticks, self.player.isPlaying()), xbmc.LOGDEBUG)
            if self.playback_error:
                log('playback failed, leaving the blank screen up', xbmc.LOGWARNING)
                self.playback_error = False
                self.av_started = False
                continue
            if self.av_started and not self.player.isPlaying():
                idle_ticks += 1
                if idle_ticks >= RESTART_AFTER_TICKS:
                    log('playback stopped on its own, restarting the clip', xbmc.LOGWARNING)
                    idle_ticks = 0
                    self.start_clip()
            else:
                idle_ticks = 0

    def start_clip(self):
        if self.closed:
            return
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        # Queued twice on purpose, see the module docstring: a one item
        # playlist goes fullscreen on its second pass.
        for _ in range(2):
            item = xbmcgui.ListItem('Dreadnought', path=VIDEO_PATH)
            item.setContentLookup(False)
            playlist.add(VIDEO_PATH, item)
        self.av_started = False
        self.playback_error = False
        self.play_started_at = time.monotonic()
        self.expect_wake = True
        # Raised before play() so a service's onAVStarted already sees it.
        set_running_flag(True)
        log('starting the clip, windowed')
        self.player.play(playlist, windowed=True)
        if self.closed:
            # The window went away while play() was in flight.
            self.player.stop()
            return
        close_busy_dialogs()
        cancel_stop_script_alarm()
        deadline = time.monotonic() + PLAYER_START_TIMEOUT
        while not self.av_started and not self.closed and time.monotonic() < deadline:
            if self.monitor.waitForAbort(0.1):
                return
        if not self.av_started:
            log('no video after {} s, repeat mode left as is'.format(PLAYER_START_TIMEOUT), xbmc.LOGWARNING)
            return
        self.set_repeat_all()

    # Player state that has to be put back on exit

    def set_repeat_all(self):
        player_id = video_player_id()
        if player_id is None:
            log('no active video player, falling back to PlayerControl(RepeatAll)', xbmc.LOGWARNING)
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
            return
        properties = jsonrpc('Player.GetProperties',
                             {'playerid': player_id, 'properties': ['repeat']}) or {}
        if self.saved_repeat is None:
            self.saved_repeat = properties.get('repeat')
        jsonrpc('Player.SetRepeat', {'playerid': player_id, 'repeat': 'all'})
        log('playing, repeat set to all (was {})'.format(self.saved_repeat))

    def restore_repeat(self):
        if self.saved_repeat not in ('off', 'one', 'all'):
            return
        player_id = video_player_id()
        if player_id is not None:
            jsonrpc('Player.SetRepeat', {'playerid': player_id, 'repeat': self.saved_repeat})
        self.saved_repeat = None

    # Shutdown, callable from any thread

    def exit(self, reason):
        with self.lock:
            if self.closed:
                return
            self.closed = True
        log('closing: {}'.format(reason))
        try:
            if self.play_started_at is not None:
                self.restore_repeat()
                if self.player.isPlaying():
                    self.player.stop()
        except Exception as exc:
            log('cleanup failed: {!r}'.format(exc), xbmc.LOGERROR)
        finally:
            # Cleared after the stop, so a service handling the stop event
            # can still see that it belonged to the screensaver.
            set_running_flag(False)
        self.close()


class MuteGuard:
    """Mutes Kodi for the life of the screensaver, outside the window.

    Application.SetMute is delivered as ACTION_MUTE to whichever window is on
    top, so it has to run before the dialog opens and after it has closed.
    """

    def __init__(self):
        self.muted_by_us = False

    def apply(self):
        if not ADDON.getSettingBool('mute'):
            return
        properties = jsonrpc('Application.GetProperties', {'properties': ['muted']}) or {}
        if properties.get('muted'):
            return
        jsonrpc('Application.SetMute', {'mute': True})
        close_volume_bar()
        self.muted_by_us = True
        log('muted')

    def restore(self):
        if self.muted_by_us:
            jsonrpc('Application.SetMute', {'mute': False})
            close_volume_bar()
            self.muted_by_us = False
            log('mute restored')


if __name__ == '__main__':
    log('starting')
    mute = MuteGuard()
    if not xbmc.Player().isPlaying():
        mute.apply()
    window = Screensaver(WINDOW_XML, ADDON_PATH, 'default', '1080i')
    window.doModal()
    del window
    mute.restore()
    log('stopped')
